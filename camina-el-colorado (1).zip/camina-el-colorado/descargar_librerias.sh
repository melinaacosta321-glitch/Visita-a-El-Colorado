#!/bin/sh
# Descarga las bibliotecas para usar el juego SIN internet. Ejecutar una sola vez, con internet.
cd "$(dirname "$0")" || exit 1
mkdir -p lib/wasm
TV=https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14
curl -L -o lib/three.module.js https://cdn.jsdelivr.net/npm/three@0.169.0/build/three.module.js
curl -L -o lib/vision_bundle.mjs $TV/vision_bundle.mjs
for f in vision_wasm_internal.js vision_wasm_internal.wasm vision_wasm_nosimd_internal.js vision_wasm_nosimd_internal.wasm; do
  curl -L -o lib/wasm/$f $TV/wasm/$f
done
curl -L -o lib/pose_landmarker_lite.task https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task
echo "Listo. La carpeta lib ya tiene todo para jugar sin conexión."
