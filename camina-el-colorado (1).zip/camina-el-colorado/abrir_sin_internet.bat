@echo off
REM Abre el juego con un servidor local (necesita Python). Dejá esta ventana abierta mientras jugás.
cd /d "%~dp0"
start "" http://localhost:8000/index.html
python -m http.server 8000 || py -m http.server 8000 || (echo No se encontro Python. Instalalo desde python.org o publica el juego en GitHub Pages. & pause)
