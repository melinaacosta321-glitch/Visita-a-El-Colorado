@echo off
REM Descarga las bibliotecas para usar el juego SIN internet. Ejecutar una sola vez, con internet.
cd /d "%~dp0"
if not exist lib\wasm mkdir lib\wasm
set TV=https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14
curl -L -o lib\three.module.js https://cdn.jsdelivr.net/npm/three@0.169.0/build/three.module.js
curl -L -o lib\vision_bundle.mjs %TV%/vision_bundle.mjs
curl -L -o lib\wasm\vision_wasm_internal.js %TV%/wasm/vision_wasm_internal.js
curl -L -o lib\wasm\vision_wasm_internal.wasm %TV%/wasm/vision_wasm_internal.wasm
curl -L -o lib\wasm\vision_wasm_nosimd_internal.js %TV%/wasm/vision_wasm_nosimd_internal.js
curl -L -o lib\wasm\vision_wasm_nosimd_internal.wasm %TV%/wasm/vision_wasm_nosimd_internal.wasm
curl -L -o lib\pose_landmarker_lite.task https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task
echo.
echo Listo. La carpeta lib ya tiene todo para jugar sin conexion.
pause
